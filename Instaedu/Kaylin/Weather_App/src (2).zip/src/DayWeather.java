public class DayWeather
{
        private double precipitation, averageTemp;
        
        public DayWeather(double averageTemp, double precipitation)
        {
            this.averageTemp = averageTemp;
            this.precipitation = precipitation;
        }
            
        public double getAverageTemp()
        {
            return averageTemp;
        }
            
        public double getPrecipitation()
        {
            return precipitation;
        }
            
        public String toString()
        {
            return "Average temp: " + getAverageTemp() + "F" + ", Precipitation: " +
            getPrecipitation() + "%";
        }
}