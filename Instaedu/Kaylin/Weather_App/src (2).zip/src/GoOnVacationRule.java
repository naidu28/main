import java.util.LinkedList;
import java.util.List;

public class GoOnVacationRule implements CustomerCityRule 
{
    public boolean isApplicable(Location location) 
    {
        List<Integer> rval = new LinkedList<>();
        
        // Small performance optimization
        if (location.size() < 4)
            return false;
        
        int count = 0;
        
        for(int i = location.size() - 4; i < location.size(); i++)
		{
            DayWeather dayWeather = location.get(i);
            
            if (dayWeather.getPrecipitation() > .75 && dayWeather.getAverageTemp() > 95) 
			{
                count++;
                
                if (count == 4)
				{
                    return true;
                }
            } 
			
			else 
			{
                count = 0;
            }
        }

        return false;
    }
}