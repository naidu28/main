import java.util.List;
import java.util.LinkedList;

public class PoolPartyRule implements CustomerCityRule 
{
    public boolean isApplicable(Location location) 
    {
        List<Integer> rval = new LinkedList<>();
        
        // Small performance optimization
        if (location.size() < 5)
            return false;
        
        int count = 0;
        
        for(int i = location.size() - 5; i < location.size(); i++)
		{
            DayWeather dayWeather = location.get(i);
            
            if (dayWeather.getPrecipitation() < .85 && dayWeather.getAverageTemp() > 75) 
			{
                count++;
                
                if (count == 5)
				{
                    return true;
                }
            } 
			
			else 
			{
                count = 0;
            }
        }

        return false;
    }
}