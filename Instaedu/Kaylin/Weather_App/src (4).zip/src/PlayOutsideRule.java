import java.util.LinkedList;
import java.util.List;

public class PlayOutsideRule implements CustomerCityRule 
{
    public boolean isApplicable(Location location) 
    {
        List<Integer> rval = new LinkedList<>();
        DayWeather dayWeather = location.get(location.size() - 1);
     
        if (dayWeather.getPrecipitation() < .3 && dayWeather.getAverageTemp() > 60 && dayWeather.getAverageTemp() < 90)
        	return true;

        return false;
    }

}