import java.util.ArrayList;

public class Location
{
    private String location;
    private ArrayList<DayWeather> days = new ArrayList<>();
    
    public Location(String location)
    {
        this.location = location;
    }
    
    public void add(DayWeather day)
    {
        days.add(day);
    }
    
	public DayWeather get(int i)
	{
		if (i < 0 || i >= days.size())
			return null;
			
		return days.get(i);
	}
	
	public String getLocation() {
		return location;
	}
	
	public String toString()
	{
		String rval = "\n"; // First part
		
		if (days.isEmpty())
		{
			rval += "No data available.";
			return rval;
		}

	   // We start on the SECOND index, index 1
		for (int i = 0; i < days.size(); i++)
		{
			rval += "\n" + "Day " + i + ": " + days.get(i).toString();
		}
		
		return rval;
	}
    
    public int size() {
        return days.size();
    }

}