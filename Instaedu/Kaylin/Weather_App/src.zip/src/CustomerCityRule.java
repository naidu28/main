import java.util.List;

public interface CustomerCityRule
{
    public boolean isApplicable(Location location);
}