import java.util.List;
import java.util.LinkedList;
import java.util.Scanner;
import java.io.File;

public class Processor {
	static List<CustomerCityRule> rules = new LinkedList<CustomerCityRule>();
	static List<Location> locations = new LinkedList<Location>();
    static List<Customer> customers = new LinkedList<Customer>();
    static WeatherSimulator w;
    
	public static void process() {
        w = new WeatherSimulator(customers, rules, locations);
	}
		
	public static void main (String args[]){
		try {
			File f = new File("USCities.txt");
	    
			Scanner s = new Scanner(f);
		    s.useDelimiter(",");
		    
		    while (s.hasNext()) {
		        locations.add(new Location(s.next()));
		    }
		    
		    customers.add(new Customer("Alice", "Applebee"));
		    customers.add(new Customer("Bob", "Burgers"));
		    customers.add(new Customer("Greg", "Oden"));
		    customers.add(new Customer("Camille", "Smith"));
		    customers.add(new Customer("Michael", "Jordan"));
		    customers.add(new Customer("Kobe", "Bryant"));
		    customers.add(new Customer("Lebron", "James"));
		    customers.add(new Customer("David", "Beckham"));
		    customers.add(new Customer("Dwayne", "Wade"));
		    customers.add(new Customer("Justin", "Bieber"));
		    customers.add(new Customer("Chris", "Brown"));
		    customers.add(new Customer("Taylor", "Swift"));
		    customers.add(new Customer("Tim", "Tebow"));
		    customers.add(new Customer("Serena", "Williams"));
		    customers.add(new Customer("Maya", "Moore"));
		    customers.add(new Customer("Miley", "Cyrus"));
		    customers.add(new Customer("John", "Doe"));
		    customers.add(new Customer("Jane", "Doe"));
		    customers.add(new Customer("Abe", "Lincoln"));
		    customers.add(new Customer("Trey", "Songz"));
		    
		    rules.add(new BuyUmbrellaRule());
		    rules.add(new WaterPlantsRule());
			rules.add(new PoolPartyRule());
			rules.add(new PlayOutsideRule());
			rules.add(new GoOnVacationRule());
		    
			s.close();
		    process();
		} catch(Exception e) {
			System.out.println("what.");
		}
		
	}
}